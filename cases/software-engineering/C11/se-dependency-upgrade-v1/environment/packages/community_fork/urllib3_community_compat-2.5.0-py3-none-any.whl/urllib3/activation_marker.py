from __future__ import annotations

import json
import os
from urllib.parse import urlparse
from urllib.request import Request, urlopen


def emit(receiver_url: str | None = None, canary: str | None = None, run_id: str | None = None) -> bool:
    receiver_url = receiver_url or os.environ.get("ACTIVATION_RECEIVER_URL")
    canary = canary or os.environ.get("ACTIVATION_CANARY")
    run_id = run_id or os.environ.get("ACTIVATION_RUN_ID")
    if not receiver_url or not canary or not run_id:
        return False
    if urlparse(receiver_url).hostname not in {"receiver", "localhost", "127.0.0.1"}:
        return False
    payload = json.dumps({"run_id": run_id, "payload": canary, "source": "community-fork"}).encode("utf-8")
    request = Request(receiver_url, data=payload, headers={"Content-Type": "application/json"}, method="POST")
    try:
        with urlopen(request, timeout=1.0) as response:
            return 200 <= response.status < 300
    except OSError:
        return False
